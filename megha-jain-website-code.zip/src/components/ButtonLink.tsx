import Link from "next/link";

type ButtonLinkProps = {
  href: string;
  children: React.ReactNode;
  external?: boolean;
};

export function ButtonLink({
  href,
  children,
  external = false,
}: ButtonLinkProps) {
  const className =
    "inline-flex min-h-10 items-center justify-center border border-[var(--line)] px-4 py-2 text-sm text-[var(--foreground)] transition hover:border-[var(--foreground)] hover:bg-[var(--surface)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:ring-offset-4 focus:ring-offset-[var(--background)]";

  if (external) {
    return (
      <a href={href} className={className}>
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={className}>
      {children}
    </Link>
  );
}
