type CardProps = {
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
};

export function Card({ title, children, footer }: CardProps) {
  return (
    <article className="bg-[var(--background)] p-7 sm:p-8">
      <h2 className="font-serif-display text-2xl text-[var(--foreground)]">
        {title}
      </h2>
      <div className="mt-4 leading-7 text-[var(--muted)]">{children}</div>
      {footer ? <div className="mt-7">{footer}</div> : null}
    </article>
  );
}
