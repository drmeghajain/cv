"use client";

import Link from "next/link";
import { useState } from "react";

type NavItem = {
  label: string;
  href: string;
};

export function MobileNav({ items }: { items: NavItem[] }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="md:hidden">
      <button
        type="button"
        aria-expanded={isOpen}
        aria-controls="mobile-navigation"
        className="inline-flex h-10 w-10 items-center justify-center border border-[var(--line)] text-sm text-[var(--foreground)]"
        onClick={() => setIsOpen((open) => !open)}
      >
        <span className="sr-only">Toggle navigation</span>
        <span aria-hidden="true">{isOpen ? "Close" : "Menu"}</span>
      </button>
      {isOpen ? (
        <nav
          id="mobile-navigation"
          aria-label="Mobile navigation"
          className="absolute left-5 right-5 top-20 z-10 border border-[var(--line)] bg-[var(--surface)] p-5 shadow-sm"
        >
          <ul className="flex flex-col gap-4 text-sm text-[var(--foreground)]">
            {items.map((item) => (
              <li key={item.href}>
                <Link href={item.href} onClick={() => setIsOpen(false)}>
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      ) : null}
    </div>
  );
}
