"use client";

import Image from "next/image";
import { useState } from "react";

type ImagePlaceholderProps = {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
};

export function ImagePlaceholder({
  src,
  alt,
  className = "",
  fallbackLabel = "Image coming soon",
}: ImagePlaceholderProps) {
  const [hasError, setHasError] = useState(false);

  return (
    <div
      className={`relative flex overflow-hidden border border-[var(--line)] bg-[var(--surface)] text-[var(--muted)] ${className}`}
    >
      {hasError ? (
        <div className="flex h-full w-full items-center justify-center bg-[#efe3d4] px-6 text-center">
          <span className="border-b border-[var(--line)] pb-2 text-xs uppercase tracking-[0.18em] text-[var(--muted)]">
            {fallbackLabel}
          </span>
        </div>
      ) : (
        <Image
          src={src}
          alt={alt}
          fill
          sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          className="object-cover"
          loading="lazy"
          unoptimized
          onError={() => setHasError(true)}
        />
      )}
    </div>
  );
}
