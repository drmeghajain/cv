type PageShellProps = {
  eyebrow?: string;
  title?: string;
  intro?: string;
  children: React.ReactNode;
};

export function PageShell({ eyebrow, title, intro, children }: PageShellProps) {
  return (
    <>
      {title ? (
        <section className="border-b border-[var(--line)] py-16 sm:py-20">
          <div className="max-w-3xl">
            {eyebrow ? (
              <p className="mb-4 text-sm uppercase tracking-[0.16em] text-[var(--muted)]">
                {eyebrow}
              </p>
            ) : null}
            <h1 className="font-serif-display text-4xl leading-tight text-[var(--foreground)] sm:text-5xl">
              {title}
            </h1>
            {intro ? (
              <p className="mt-6 text-lg leading-8 text-[var(--muted)]">
                {intro}
              </p>
            ) : null}
          </div>
        </section>
      ) : null}
      {children}
    </>
  );
}
