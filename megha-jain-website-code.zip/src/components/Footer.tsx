import { siteLinks } from "@/content/siteContent";

export function Footer() {
  return (
    <footer className="border-t border-[var(--line)] py-7 text-xs text-[var(--muted)]">
      <div className="mx-auto flex max-w-5xl flex-col gap-5 md:flex-row md:items-center md:justify-between">
        <ul className="flex flex-wrap gap-x-5 gap-y-3">
          <li>
            <a className="hover:text-[var(--foreground)]" href={siteLinks.email}>
              Email
            </a>
          </li>
          <li>
            <a className="hover:text-[var(--foreground)]" href={siteLinks.linkedIn}>
              LinkedIn
            </a>
          </li>
          <li>
            <a className="hover:text-[var(--foreground)]" href={siteLinks.resume}>
              Resume
            </a>
          </li>
        </ul>
        <p>&copy; {new Date().getFullYear()} Dr Megha Jain</p>
      </div>
    </footer>
  );
}
