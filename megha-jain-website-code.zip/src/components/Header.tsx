import Link from "next/link";
import { navItems } from "@/content/siteContent";
import { MobileNav } from "@/components/MobileNav";

export function Header() {
  return (
    <header className="flex items-center justify-between border-b border-[var(--line)] py-5">
      <Link
        href="#home"
        className="font-serif-display text-xl tracking-normal text-[var(--foreground)]"
      >
        Dr Megha Jain
      </Link>
      <nav aria-label="Primary navigation" className="hidden md:block">
        <ul className="flex items-center gap-7 text-sm text-[var(--muted)]">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className="transition hover:text-[var(--foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:ring-offset-4 focus:ring-offset-[var(--background)]"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <MobileNav items={navItems} />
    </header>
  );
}
