export const siteLinks = {
  email: "mailto:meghajainau@gmail.com",
  emailLabel: "meghajainau@gmail.com",
  linkedIn: "https://www.linkedin.com/in/meghajainau",
  resume: "/Megha-Jain-Resume.pdf",
  samplePdf: "/samples/creative-social-samples.pdf",
};

export const sampleStatus = "Sample coming soon";

export const navItems = [
  { label: "Home", href: "#home" },
  { label: "Marketing", href: "#marketing" },
  { label: "Research", href: "#research" },
  { label: "Photography", href: "#photography" },
  { label: "Contact", href: "#contact" },
];

export const home = {
  name: "Dr Megha Jain",
  portrait: "/images/megha-portrait.jpg",
  portraitAlt: "Portrait of Dr Megha Jain",
  intro:
    "I translate complex ideas into clear, credible and engaging communication through marketing strategy, visual storytelling, research and digital content.",
  actions: [
    { label: "Marketing Portfolio", href: "#marketing" },
    { label: "DBA Research", href: "#research" },
    { label: "Photography", href: "#photography" },
    { label: "Contact", href: "#contact" },
  ],
};

export const portfolioCards = [
  {
    title: "Social & Behaviour-Change Copy",
    label: "Writing sample",
    sourceNote: "The Meraki Movement",
    body: "Wellbeing-focused social copy using direct, motivational language to help audiences connect personal change with everyday action. This sample shows my ability to write with empathy, clarity and behavioural intent.",
    skills:
      "Behaviour-change messaging · Social copywriting · Audience empathy · Wellbeing communication",
    link: siteLinks.samplePdf,
  },
  {
    title: "Complex Product Storytelling",
    label: "Product storytelling sample",
    sourceNote: "Assurekit Technologies",
    body: "Explanatory content translating embedded insurance into simple, customer-focused language. This sample shows how I simplify technical or unfamiliar products by focusing on relevance, timing, trust and customer journey.",
    skills:
      "Plain-language explanation · Product storytelling · Customer journey thinking · Trust-building",
    link: siteLinks.samplePdf,
  },
  {
    title: "Brand, Campaign & Creative Coordination",
    label: "Campaign communication",
    sourceNote: "HCLSoftware / selected campaign work",
    body: "Campaign and content experience across digital, EDM, events, social, stakeholder communication and sales-support material. This area shows how I connect messaging, creative direction, brand consistency and practical execution.",
    skills:
      "Brand governance · Campaign messaging · Creative briefing · Stakeholder communication",
    link: siteLinks.samplePdf,
  },
  {
    title: "Analytics-to-Action Thinking",
    label: "Analytics sample",
    sourceNote: "DoorDash analysis report",
    body: "Analysis of customer, regional, transaction, driver and restaurant data, translated into recommendations around engagement, route optimisation, local advertising, service improvement and personalisation.",
    skills:
      "Analytics · Audience insight · Reporting · Optimisation · AI/personalisation thinking",
    link: siteLinks.samplePdf,
  },
  {
    title: "Creative & Social Ideas",
    label: "Strategy sample",
    sourceNote: "Selected social and digital thinking",
    body: "Social-first campaign thinking showing how I approach platform behaviour, public engagement, narrative development and message adaptation across different audiences.",
    skills: "Creative strategy · Social content · Message development · Platform thinking",
    link: siteLinks.samplePdf,
  },
];

export const research = {
  title: "Research on Trust, Adoption and Behaviour Change",
  intro: [
    "My doctoral research examined how organisations encourage adoption of a culturally sensitive, health-related product in a market shaped by stigma, hesitation and low consumer familiarity.",
    "The study explored how brands build legitimacy through education, trust signals, community outreach, affordability, accessibility, credibility and product innovation.",
    "While the research focused on one sensitive product category, the underlying lessons apply far more widely: any organisation introducing an unfamiliar idea must help people understand it, trust it, imagine using it and feel safe enough to act.",
  ],
  sections: [
    {
      title: "What I studied",
      body: "A qualitative multiple-case study of three brands, anonymised as Brand A, Brand B and Brand C, examining how each used marketing strategy to support adoption of a culturally sensitive product.",
    },
    {
      title: "How brands build trust",
      body: "The research showed that trust is built through education, credible voices, peer reassurance, community outreach, practical support and repeated signals of safety and legitimacy.",
    },
    {
      title: "What the research found",
      body: "Adoption is not created by awareness alone. People need meaning, confidence, social permission, accessible information and a clear reason to change behaviour.",
    },
    {
      title: "How this transfers",
      body: "These lessons can apply to AI tools, health products, fintech, sustainability, public-sector behaviour change, women's health, emerging technology and any product people hesitate to understand, trust or adopt.",
    },
  ],
};

export const photography = {
  title: "Photography & Visual Storytelling",
  intro: "Photography taught me how people see before they read.",
  featured: {
    title: "Astitva",
    body: "Astitva was my MFA thesis project in environmental portraiture, exploring identity, work and joy through portraits of local business owners in San Francisco. The project shaped how I think about visual trust, emotion, composition and the relationship between people and their environments.",
    note: "Today, that visual training informs my work in brand storytelling, creative strategy and audience-centred communication.",
    image: "/images/photography/astitva-01.jpg",
    alt: "Astitva photography project placeholder image",
  },
  gallery: [
    {
      src: "/images/photography/astitva-01.jpg",
      alt: "Astitva project image one placeholder",
    },
    {
      src: "/images/photography/astitva-02.jpg",
      alt: "Astitva project image two placeholder",
    },
    {
      src: "/images/photography/portrait-01.jpg",
      alt: "Portrait photography placeholder",
    },
    {
      src: "/images/photography/travel-01.jpg",
      alt: "Travel photography placeholder",
    },
  ],
};

export const contact = {
  title: "Let's connect.",
  body: "If you are looking for someone who can translate complex ideas into clear strategy, strong storytelling and audience-centred communication, I would be pleased to hear from you.",
};
