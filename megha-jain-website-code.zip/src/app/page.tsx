import { ButtonLink } from "@/components/ButtonLink";
import { Card } from "@/components/Card";
import { ImagePlaceholder } from "@/components/ImagePlaceholder";
import {
  contact,
  home,
  photography,
  portfolioCards,
  research,
  sampleStatus,
  siteLinks,
} from "@/content/siteContent";

export default function HomePage() {
  return (
    <>
      <section
        id="home"
        className="flex min-h-[calc(100vh-11rem)] scroll-mt-20 items-center py-12 sm:py-16 md:py-20"
      >
        <div className="mx-auto grid w-full max-w-5xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr] md:gap-16">
          <div className="w-full max-w-sm justify-self-center md:max-w-md md:justify-self-start">
            <ImagePlaceholder
              src={home.portrait}
              alt={home.portraitAlt}
              fallbackLabel="Portrait image"
              className="aspect-[5/4] w-full sm:aspect-[4/5]"
            />
          </div>
          <div className="max-w-2xl md:pt-4">
            <p className="mb-4 text-xs uppercase tracking-[0.18em] text-[var(--muted)]">
              Marketing strategy, visual storytelling & research
            </p>
            <h1 className="font-serif-display text-5xl leading-tight text-[var(--foreground)] sm:text-6xl">
              {home.name}
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-[var(--muted)]">
              {home.intro}
            </p>
            <div className="mt-9 flex flex-wrap gap-2.5">
              {home.actions.map((action) => (
                <ButtonLink key={action.href} href={action.href}>
                  {action.label}
                </ButtonLink>
              ))}
            </div>
          </div>
        </div>
      </section>

      <SectionHeader
        id="marketing"
        eyebrow="Marketing Portfolio"
        title="Selected marketing thinking"
        intro="A compact view of strategic communication, campaign thinking and audience-centred storytelling."
      />
      <section className="pb-20 sm:pb-24" aria-label="Marketing portfolio samples">
        <div className="grid gap-px overflow-hidden border border-[var(--line)] bg-[var(--line)] md:grid-cols-2">
          {portfolioCards.map((card) => (
            <Card
              key={card.title}
              title={card.title}
              footer={
                <>
                  {/* TODO: Add the actual creative/social sample PDF before launch. */}
                  <div className="flex flex-wrap items-center gap-3">
                    <ButtonLink href={card.link}>View selected sample</ButtonLink>
                    <span className="text-xs text-[var(--muted)]">{sampleStatus}</span>
                  </div>
                </>
              }
            >
              <p className="mb-3 text-xs uppercase tracking-[0.16em] text-[var(--muted)]">
                {card.label}
              </p>
              <p className="mb-4 text-sm text-[var(--foreground)]">{card.sourceNote}</p>
              <p>{card.body}</p>
              <p className="mt-5 text-sm text-[var(--foreground)]">{card.skills}</p>
            </Card>
          ))}
        </div>
      </section>

      <SectionHeader
        id="research"
        eyebrow="DBA Research"
        title={research.title}
        intro={research.intro}
      />
      <section className="pb-20 sm:pb-24" aria-label="Research sections">
        <div className="divide-y divide-[var(--line)]">
          {research.sections.map((section) => (
            <article
              key={section.title}
              className="grid gap-4 py-8 md:grid-cols-[0.35fr_0.65fr] md:gap-10"
            >
              <h3 className="font-serif-display text-2xl text-[var(--foreground)]">
                {section.title}
              </h3>
              <p className="max-w-3xl leading-8 text-[var(--muted)]">{section.body}</p>
            </article>
          ))}
        </div>
      </section>

      <SectionHeader
        id="photography"
        eyebrow="Photography"
        title={photography.title}
        intro={photography.intro}
      />
      <section className="pb-20 sm:pb-24" aria-label="Photography and visual storytelling">
        <div className="grid gap-8 border-b border-[var(--line)] pb-12 md:grid-cols-[0.58fr_0.42fr] md:items-end">
          <ImagePlaceholder
            src={photography.featured.image}
            alt={photography.featured.alt}
            fallbackLabel="Astitva image"
            className="aspect-[4/3] w-full"
          />
          <div>
            <p className="text-sm uppercase tracking-[0.16em] text-[var(--muted)]">
              Featured project
            </p>
            <h3 className="font-serif-display mt-3 text-3xl text-[var(--foreground)]">
              {photography.featured.title}
            </h3>
            <p className="mt-5 leading-8 text-[var(--muted)]">
              {photography.featured.body}
            </p>
            <p className="mt-4 leading-8 text-[var(--muted)]">
              {photography.featured.note}
            </p>
          </div>
        </div>
        <div className="grid gap-4 pt-10 sm:grid-cols-2 lg:grid-cols-4">
          {photography.gallery.map((image) => (
            <ImagePlaceholder
              key={image.src}
              src={image.src}
              alt={image.alt}
              fallbackLabel="Image"
              className="aspect-[3/4] w-full"
            />
          ))}
        </div>
      </section>

      <SectionHeader id="contact" title={contact.title} intro={contact.body} />
      <section className="pb-20 sm:pb-24" aria-label="Contact links">
        <div className="flex flex-wrap gap-2.5">
          <ButtonLink href={siteLinks.email} external>
            Email
          </ButtonLink>
          <ButtonLink href={siteLinks.linkedIn} external>
            LinkedIn
          </ButtonLink>
          <ButtonLink href={siteLinks.resume}>Resume</ButtonLink>
        </div>
        <p className="mt-8 text-sm text-[var(--muted)]">{siteLinks.emailLabel}</p>
      </section>
    </>
  );
}

function SectionHeader({
  id,
  eyebrow,
  title,
  intro,
}: {
  id: string;
  eyebrow?: string;
  title: string;
  intro?: string | string[];
}) {
  const introItems = Array.isArray(intro) ? intro : intro ? [intro] : [];

  return (
    <section
      id={id}
      className="scroll-mt-20 border-t border-[var(--line)] pt-16 sm:pt-20"
    >
      <div className="max-w-3xl pb-10">
        {eyebrow ? (
          <p className="mb-4 text-xs uppercase tracking-[0.18em] text-[var(--muted)]">
            {eyebrow}
          </p>
        ) : null}
        <h2 className="font-serif-display text-4xl leading-tight text-[var(--foreground)] sm:text-5xl">
          {title}
        </h2>
        {introItems.map((item) => (
          <p
            key={item}
            className="mt-5 max-w-2xl text-lg leading-8 text-[var(--muted)]"
          >
            {item}
          </p>
        ))}
      </div>
    </section>
  );
}
