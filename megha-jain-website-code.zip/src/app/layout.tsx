import type { Metadata } from "next";
import "./globals.css";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

export const metadata: Metadata = {
  title:
    "Dr Megha Jain | Marketing Strategy, Visual Storytelling & Research-Led Communication",
  description:
    "A minimal portfolio website for Dr Megha Jain, Melbourne-based marketing strategist, visual storyteller and research-led communications professional.",
};

const serifStack =
  'Georgia, "Times New Roman", "Iowan Old Style", "Palatino Linotype", serif';
const sansStack =
  'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      style={
        { "--font-serif": serifStack, "--font-sans": sansStack } as React.CSSProperties
      }
    >
      <body className="min-h-screen">
        <div className="mx-auto flex min-h-screen w-full max-w-6xl flex-col px-5 sm:px-8">
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
